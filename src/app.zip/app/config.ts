export class mainurl{
    baseURL: string = "https://192.168.1.10:5000";
    // baseURL: string = "https://demopms.daerp.in";
    // baseURL: string = "https://192.168.1.10:5600";
}