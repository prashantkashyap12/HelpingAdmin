import { Component } from '@angular/core';

@Component({
  selector: 'app-help-comp',
  standalone: true,
  imports: [],
  templateUrl: './help-comp.component.html',
  styleUrl: './help-comp.component.css'
})
export class HelpCompComponent {

}
