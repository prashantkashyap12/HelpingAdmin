import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-set',
  standalone: true,
  imports: [],
  templateUrl: './profile-set.component.html',
  styleUrl: './profile-set.component.css'
})
export class ProfileSetComponent {

}
