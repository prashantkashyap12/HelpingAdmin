import { Component } from '@angular/core';

@Component({
  selector: 'app-file-manager',
  standalone: true,
  imports: [],
  templateUrl: './file-manager.component.html',
  styleUrl: './file-manager.component.css'
})
export class FileManagerComponent {

}
